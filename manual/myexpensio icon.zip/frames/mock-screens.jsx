// Mocks that live inside iOS frames for the user guide.
// Each mount point is a div id like "mock-home"; we render an IOSDevice into it.

const mockFrameSize = { width: 402, height: 820 };

function MockHome() {
  return (
    <IOSDevice {...mockFrameSize} title="myexpensio">
      <div className="pf">
        <div className="pf-quick">
          <div>
            <div className="q-t">trips · apr</div>
            <div className="q-v">14</div>
          </div>
          <div>
            <div className="q-t">routes used</div>
            <div className="q-v">1 / 2</div>
          </div>
          <div>
            <div className="q-t">draft claim</div>
            <div className="q-v">RM 612.40</div>
          </div>
          <div>
            <div className="q-t">submitted</div>
            <div className="q-v">3</div>
          </div>
        </div>
        <div className="pf-card">
          <a className="pf-btn blue">Start Trip</a>
          <a className="pf-btn ghost" style={{marginTop:8}}>Plan Trip</a>
          <a className="pf-btn ghost" style={{marginTop:8}}>New Claim</a>
          <a className="pf-btn ghost" style={{marginTop:8}}>Export</a>
        </div>
        <div className="pf-card">
          <div style={{font: '500 11px/1 var(--font-mono)', color:'var(--ink-3)', textTransform:'uppercase', letterSpacing:'0.05em', marginBottom:8}}>recent trips</div>
          <div className="pf-list-item"><div><div className="pl-t">KL → Shah Alam</div><div className="pl-s">18 apr · 09:14 → 10:02</div></div><div className="val num" style={{font:'500 13px/1 var(--font-mono)', color:'var(--ink)'}}>24.8 km</div></div>
          <div className="pf-list-item"><div><div className="pl-t">Office → Client HQ</div><div className="pl-s">17 apr · 14:20 → 15:05</div></div><div className="val num" style={{font:'500 13px/1 var(--font-mono)', color:'var(--ink)'}}>12.4 km</div></div>
          <div className="pf-list-item"><div><div className="pl-t">Client HQ → Office</div><div className="pl-s">17 apr · 17:10 → 17:55</div></div><div className="val num" style={{font:'500 13px/1 var(--font-mono)', color:'var(--ink)'}}>12.6 km</div></div>
        </div>
      </div>
    </IOSDevice>
  );
}

function MockTrip() {
  return (
    <IOSDevice {...mockFrameSize} title="Trip · live">
      <div className="pf">
        <div className="pf-card">
          <span className="pf-pill">● tracking on</span>
          <div className="pf-map"/>
          <div className="pf-row"><span className="lbl">Distance</span><span className="val num">8.42 km</span></div>
          <div className="pf-row"><span className="lbl">Duration</span><span className="val">00:18:24</span></div>
          <div className="pf-row"><span className="lbl">Points</span><span className="val">214</span></div>
          <a className="pf-btn" style={{marginTop:12}}>Stop Trip</a>
        </div>
        <div className="pf-card">
          <div style={{font: '500 11px/1 var(--font-mono)', color:'var(--ink-3)', textTransform:'uppercase', letterSpacing:'0.05em', marginBottom:8}}>distance source</div>
          <div className="pf-row"><span className="lbl">GPS tracking</span><span className="pf-pill blue">selected</span></div>
          <div className="pf-row"><span className="lbl">Odometer override</span><span className="val" style={{color:'var(--ink-3)'}}>add</span></div>
        </div>
      </div>
    </IOSDevice>
  );
}

function MockClaim() {
  return (
    <IOSDevice {...mockFrameSize} title="March 2026">
      <div className="pf">
        <div className="pf-card">
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'baseline'}}>
            <div>
              <div style={{font: '500 11px/1 var(--font-mono)', color:'var(--ink-3)', textTransform:'uppercase', letterSpacing:'0.05em'}}>draft total</div>
              <div className="pf-big" style={{marginTop:6}}>RM 1,284.60</div>
            </div>
            <span className="pf-pill warn">draft</span>
          </div>
        </div>
        <div className="pf-card">
          <div className="pf-list-item"><div><div className="pl-t">Mileage · 14 trips</div><div className="pl-s">218.4 km × RM 0.70</div></div><div className="val num" style={{font:'500 13px/1 var(--font-mono)'}}>RM 152.88</div></div>
          <div className="pf-list-item"><div><div className="pl-t">Toll · TNG</div><div className="pl-s">6 transactions · linked</div></div><div className="val num" style={{font:'500 13px/1 var(--font-mono)'}}>RM 84.40</div></div>
          <div className="pf-list-item"><div><div className="pl-t">Parking</div><div className="pl-s">3 items</div></div><div className="val num" style={{font:'500 13px/1 var(--font-mono)'}}>RM 28.00</div></div>
          <div className="pf-list-item"><div><div className="pl-t">Meal</div><div className="pl-s">5 sessions</div></div><div className="val num" style={{font:'500 13px/1 var(--font-mono)'}}>RM 240.00</div></div>
          <div className="pf-list-item"><div><div className="pl-t">Lodging</div><div className="pl-s">2 nights · KK</div></div><div className="val num" style={{font:'500 13px/1 var(--font-mono)'}}>RM 620.00</div></div>
          <div className="pf-list-item"><div><div className="pl-t">Per diem</div><div className="pl-s">4 days</div></div><div className="val num" style={{font:'500 13px/1 var(--font-mono)'}}>RM 160.00</div></div>
        </div>
        <a className="pf-btn blue">Submit Claim</a>
      </div>
    </IOSDevice>
  );
}

function MockTng() {
  return (
    <IOSDevice {...mockFrameSize} title="TNG">
      <div className="pf">
        <div className="pf-card">
          <div style={{font: '500 11px/1 var(--font-mono)', color:'var(--ink-3)', textTransform:'uppercase', letterSpacing:'0.05em', marginBottom:8}}>statement · mar 2026</div>
          <div className="pf-row"><span className="lbl">Rows parsed</span><span className="val">132</span></div>
          <div className="pf-row"><span className="lbl">Linked</span><span className="val" style={{color:'oklch(0.48 0.12 155)'}}>24</span></div>
          <div className="pf-row"><span className="lbl">Unlinked</span><span className="val" style={{color:'oklch(0.55 0.12 75)'}}>108</span></div>
        </div>
        <div className="pf-card">
          <div className="pf-list-item"><div><div className="pl-t">PLUS Tambak Johor</div><div className="pl-s">04 mar · toll</div></div><span className="pf-pill">linked</span></div>
          <div className="pf-list-item"><div><div className="pl-t">KLIA Parking B</div><div className="pl-s">07 mar · parking</div></div><span className="pf-pill">linked</span></div>
          <div className="pf-list-item"><div><div className="pl-t">Sungai Besi Toll</div><div className="pl-s">09 mar · toll</div></div><span className="pf-pill warn">suggested</span></div>
          <div className="pf-list-item"><div><div className="pl-t">Gombak Toll</div><div className="pl-s">12 mar · toll</div></div><span className="pf-pill warn">unlinked</span></div>
          <div className="pf-list-item"><div><div className="pl-t">FamilyMart KLCC</div><div className="pl-s">14 mar · retail</div></div><span className="pf-pill" style={{background:'var(--bg-sunken)', color:'var(--ink-3)'}}>unmatched</span></div>
        </div>
      </div>
    </IOSDevice>
  );
}

function MockExport() {
  return (
    <IOSDevice {...mockFrameSize} title="Export">
      <div className="pf">
        <div className="pf-card">
          <div className="pf-input"><span>Template</span><span className="ph">Finance — Default</span></div>
          <div className="pf-input"><span>Date range</span><span className="ph">1–31 Mar 2026</span></div>
          <div className="pf-input"><span>Status</span><span className="ph">Submitted</span></div>
        </div>
        <div className="pf-card">
          <div style={{font: '500 11px/1 var(--font-mono)', color:'var(--ink-3)', textTransform:'uppercase', letterSpacing:'0.05em', marginBottom:8}}>format</div>
          <div className="pf-row"><span className="lbl">CSV</span><span className="val" style={{color:'var(--ink-3)'}}>select</span></div>
          <div className="pf-row"><span className="lbl">XLSX</span><span className="val" style={{color:'var(--ink-3)'}}>select</span></div>
          <div className="pf-row"><span className="lbl">PDF · with TNG appendix</span><span className="pf-pill blue">selected</span></div>
        </div>
        <a className="pf-btn blue">Generate Export</a>
        <div className="pf-card" style={{marginTop:12}}>
          <div style={{font: '500 11px/1 var(--font-mono)', color:'var(--ink-3)', textTransform:'uppercase', letterSpacing:'0.05em', marginBottom:8}}>history</div>
          <div className="pf-list-item"><div><div className="pl-t">March · PDF</div><div className="pl-s">18 apr · 09:42</div></div><span className="pf-pill">done</span></div>
          <div className="pf-list-item"><div><div className="pl-t">February · XLSX</div><div className="pl-s">04 mar · 18:11</div></div><span className="pf-pill">done</span></div>
        </div>
      </div>
    </IOSDevice>
  );
}

// Mount on DOM elements
const mounts = [
  ['mock-home',   <MockHome/>],
  ['mock-trip',   <MockTrip/>],
  ['mock-claim',  <MockClaim/>],
  ['mock-tng',    <MockTng/>],
  ['mock-export', <MockExport/>],
];
mounts.forEach(([id, node]) => {
  const el = document.getElementById(id);
  if (el) ReactDOM.createRoot(el).render(node);
});
